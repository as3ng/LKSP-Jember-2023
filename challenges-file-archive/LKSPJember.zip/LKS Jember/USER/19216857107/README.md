# 19216857107 [975 pts]

**Category:** USER
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

