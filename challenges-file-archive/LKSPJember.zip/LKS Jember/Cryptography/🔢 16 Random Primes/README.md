# \xf0\x9f\x94\xa2 16 Random Primes [1000 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>Yuk kita mulai menjelajahi algoritma lainnya, apakah kamu pernah mendengar tentang RSA?\r\n\r\nBoleh ditengok sejarahnya disini -> https://id.wikipedia.org/wiki/RSA\r\n\r\nAda begitu banyak implementasi RSA yang cukup ""lemah"" karena desain algoritma yang dibuat terlalu mudah ditebak atau sifatnya bisa dibalikkan kembali karena kesalahan penggunaan yang tidak mengikuti praktik yang benar.\r\n\r\nDapatkah kamu mendapatkan `FLAG`-nya kembali dengan normal? (yang sudah di enkripsi dan disimpan dalam variabel `ct`)\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* -

## Solution

### Flag

