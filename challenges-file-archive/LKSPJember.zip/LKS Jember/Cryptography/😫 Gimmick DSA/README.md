# \xf0\x9f\x98\xab Gimmick DSA [1000 pts]

**Category:** Cryptography
**Solves:** 0

## Description
>Kami baru saja membuat aplikasi **LKSVerisign** khusus untuk Anda dalam melakukan verifikasi identitas.\r\n\r\nApakah kalian dapat *mencemari* integritas itu? Dapatkah kalian menjadi **Super User** pada aplikasi kami?\r\n\r\nAnda dapat mengetes aplikasi kami secara `remote` dengan menggunakan servis `netcat` di bawah ini.\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* Sistem DSA ini tidak memiliki verifikasi digital sama sekali, malah developernya memakai sebuah *hashing*. *Hashing* sering digunakan untuk mengecek integritas data dengan baik, tapi apa semua algoritma *hashing* itu aman untuk digunakan?

## Solution

### Flag

