# \xf0\x9f\x98\x88 PHPWare [1000 pts]

**Category:** Digital Forensic
**Solves:** 0

## Description
>Sebulan yang lalu, aku dipanggil oleh PIC Kantorku dan dikabarkan bahwa website kantor telah diretas oleh seseorang dengan inisial "*hacker1337jember*". \r\n\r\nDiketahui bahwa penyerang ini menyisipkan sebuah **webshell** ke dalam website kantor namun saat aku lihat, tidak ada apa-apa disana. Aku curiga bahwa dia menyisipkan **webshell-nya ke dalam default page HTML dari website kantorku**. Anehnya, penyerang itu malah meng-**kompres** seluruh isi folder website kantorku ke dalam bentuk NTFS RAR. Apa ya tujuannya?\r\n\r\nDapatkah kamu membantuku menemukan webshell-nya? \r\n\r\nCatatan: Jangan lupa saat menemukan flagnya, tolong di enkapsulasi dengan prefix format `LKS2023Jatim{}`\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* Ada fitur spesial pada WinRAR yang dapat digunakan untuk menyisipkan suatu data, kira-kira apakah fitur itu?

## Solution

### Flag

