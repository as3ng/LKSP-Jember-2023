# \xf0\x9f\x94\x8d SimpleC2 [1000 pts]

**Category:** Digital Forensic
**Solves:** 0

## Description
>Baru saja aku pulang dari kantor setelah menyelesaikan kasus *hacker1337jember*, sekarang aku ditelpon lagi karena barusan seorang karyawan bernama *aseng* di kantor tertangkap basah sedang menjalankan **aktivitas ilegal** dengan rekannya di Jember juga (secara remote). **Aktivitas ilegal** tersebut bertujuan agar rekan *aseng* di Jember dapat mendapatkan informasi mengenai folder privat dan file privat milik *aseng*.\r\n\r\nHal ini diketahui oleh pihak SOC kantor karena mereka merekam traffic kantor dengan menggunakan `Wireshark`. Namun setelah dicek, sebenarnya mereka heran karena **protokol** yang biasa digunakan sungguh tidak biasa. Dapatkah kamu mendapatkan:\r\n\r\n**a) Nama Folder Privat yang dimaksud**\r\n\r\n**b) Konten yang ada di dalam file privat (di dalam folder privat)**\r\n\r\n**Gabungkan keduanya menjadi sebuah flag.**\r\n\r\nContoh:\r\n\r\na) folder_rahasia\r\n\r\nb) halo_semua_peserta_lks\r\n\r\nMaka flagnya:\r\n\r\n**folder_rahasiahalo_semua_peserta_lks**\r\n\r\nJangan lupa di-wrap dengan prefix yang sudah ditentukan oleh juri, yaitu `LKS2023Jatim{}`.\r\n\r\nNotes tambahan: Nama folder privat dan konten yang ada di dalam file privatnya memiliki bentuk seperti *strings "alay"*, seperti **1n1_str1ngs_4l4y**, bukan Ini_Strings.\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* -

## Solution

### Flag

