# \xf0\x9f\x8e\x89 Free Flag Click Here! [1000 pts]

**Category:** Misc
**Solves:** 0

## Description
>Halo selamat datang di LKS Jember bidang Cybersecurity. Tugas kamu adalah untuk memenuhi objektif di setiap soal agar mendapatkan sebuah string yang disebut dengan sebuah **FLAG**.\r\n\r\nObjektif yang dimaksud bisa sangat beragam, mulai dari mengeksploitasi suatu servis, aplikasi ataupun menemukan artefak jejak digital dan sebagainya.\r\n\r\nObjektif pertamamu adalah melakukan submit FLAG langsung dari **FLAG** yang kami berikan di bawah ini:\r\n\r\n`LKSJatim2023{s3l4m4t_d4t4ng_di_LKS_Provinsi_s3moga_k4mu_masuk_LKSN_selanjutnya!_GLHF}`

**Hint**
* -

## Solution

### Flag

