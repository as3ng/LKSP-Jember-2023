# \xf0\x9f\x90\x8d Prison Break [1000 pts]

**Category:** Misc
**Solves:** 0

## Description
>Dapatkah kamu mendapatkan **FLAG** dari sebuah file yang aku buat bersama dengan pemrosesan\r\nprogram **Python** ini? Aku sudah mengeliminasi beberapa karakter yang tidak boleh digunakan\r\nsehingga tidak akan semudah itu kamu dapatkan!\r\n\r\nAnda dapat mengetes aplikasi kami secara `remote` dengan menggunakan servis `netcat` di bawah ini.\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* -

## Solution

### Flag

