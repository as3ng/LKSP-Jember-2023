# 19216857117 [975 pts]

**Category:** ROOT
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

