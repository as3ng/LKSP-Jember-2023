# 19216857115 [975 pts]

**Category:** ROOT
**Solves:** 3

## Description
>

**Hint**
* -

## Solution

### Flag

