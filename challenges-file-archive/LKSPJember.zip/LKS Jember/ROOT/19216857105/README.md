# 19216857105 [989 pts]

**Category:** ROOT
**Solves:** 2

## Description
>

**Hint**
* -

## Solution

### Flag

