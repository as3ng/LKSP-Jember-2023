# 19216857106 [956 pts]

**Category:** ROOT
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

