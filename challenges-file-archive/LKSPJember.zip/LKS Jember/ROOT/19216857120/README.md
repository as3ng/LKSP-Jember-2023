# 19216857120 [931 pts]

**Category:** ROOT
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

