# 19216857113 [956 pts]

**Category:** ROOT
**Solves:** 3

## Description
>

**Hint**
* -

## Solution

### Flag

