# 19216857102 [989 pts]

**Category:** ROOT
**Solves:** 3

## Description
>

**Hint**
* -

## Solution

### Flag

