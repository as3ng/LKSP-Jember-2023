# 19216857104 [956 pts]

**Category:** ROOT
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

