# 19216857107 [975 pts]

**Category:** ROOT
**Solves:** 3

## Description
>

**Hint**
* -

## Solution

### Flag

