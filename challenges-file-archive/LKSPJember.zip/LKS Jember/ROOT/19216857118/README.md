# 19216857118 [975 pts]

**Category:** ROOT
**Solves:** 4

## Description
>

**Hint**
* -

## Solution

### Flag

