# 19216857110 [931 pts]

**Category:** ROOT
**Solves:** 5

## Description
>

**Hint**
* -

## Solution

### Flag

