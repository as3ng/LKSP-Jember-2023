# \xf0\x9f\x91\xb6 Spoiled Program [1000 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Program ini dibuat **sangat manja** karena dia tidak mau memberikan `FLAG` yang menjadi objektif peserta **kecuali** dijalankan di sistem operasi aneh selain **Windows**, yang padahal ekstensinya sendiri merupakan `.exe`.\r\n\r\nDapatkah kalian sebagai _reverse engineer_ yang baik membantu kami untuk mendapatkan `FLAG`-nya?\r\n\r\nJangan lupa jika kamu menemukan FLAG/jawabannya, selalu di enkapsulasi dengan `LKS2023Jatim{}`. \r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* Objektifnya hanya menjalankan programnya dengan benar sehingga Anda dapat menerima flagnya. Objektif soal ini melibatkan sebuah **modifikasi komponen** pada sistem operasi Windows, kira-kira apa yang membuat file *executable* ini dapat mencari tahu sistem operasi Anda?

## Solution

### Flag

