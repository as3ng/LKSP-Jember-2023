# \xf0\x9f\x91\x91 End Game [1000 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Seorang raja selalu memiliki **tanda tangan rahasia** yang tidak pernah diketahui orang lain ~, tapi hati-hati soal ini agak *weebyuw*.\r\n\r\nDownload attachment-nya [disini](https://expo.dev/artifacts/eas/rGdYoBNuxoi3c135iTXsz8.apk)\r\n\r\nAuthor: Chrisando (siahaan#9550)

**Hint**
* -

## Solution

### Flag

