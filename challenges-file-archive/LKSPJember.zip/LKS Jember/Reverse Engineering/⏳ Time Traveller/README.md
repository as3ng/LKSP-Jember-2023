# \xe2\x8f\xb3 Time Traveller [1000 pts]

**Category:** Reverse Engineering
**Solves:** 0

## Description
>Pak Adhitya, Pak Chrisando, Pak Stanley, dan Pak Felix sedang mengoprek sebuah program aneh yang tidak menerima input dari user. Tetapi ada beberapa validasi yang memungkinkan pesertanya mendapatkan sebuah `FLAG`. \r\n\r\nNamun sayangnya tidak semudah itu. Bisakah kamu mendapatkan `FLAG`-nya dari program ini? Konon katanya hanya seseorang yang dari **masa lalu** yang dapat menjalankan program ini dan langsung mendapatkan `FLAG`-nya.\r\n\r\nJangan lupa jika Anda berhasil mendapatkan *readable* inputnya, selalu di enkapsulasi dengan `LKS2023Jatim{}` untuk memvalidasi `FLAG`-nya.\r\n\r\nAuthor: Felix (aseng#2055)

**Hint**
* -

## Solution

### Flag

