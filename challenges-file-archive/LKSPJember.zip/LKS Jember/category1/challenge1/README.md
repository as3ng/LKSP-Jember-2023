# challenge1 [100 pts]

**Category:** category1
**Solves:** 0

## Description
>challenge description

**Hint**
* -

## Solution

### Flag

